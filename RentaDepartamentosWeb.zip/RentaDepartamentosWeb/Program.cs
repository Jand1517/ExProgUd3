var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Registro de dependencias para Renta de Departamentos
builder.Services.AddScoped<RentaDepartamentosWeb.Data.ConexionBD>();
builder.Services.AddScoped<RentaDepartamentosWeb.Repositories.IDepartamentoRepository, RentaDepartamentosWeb.Repositories.DepartamentoRepository>();
builder.Services.AddScoped<RentaDepartamentosWeb.Services.IDepartamentoService, RentaDepartamentosWeb.Services.DepartamentoService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Departamento}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
