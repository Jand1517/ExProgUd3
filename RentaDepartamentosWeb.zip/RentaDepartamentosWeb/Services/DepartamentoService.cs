using System;
using System.Collections.Generic;
using RentaDepartamentosWeb.Models;
using RentaDepartamentosWeb.Repositories;

namespace RentaDepartamentosWeb.Services
{
    public class DepartamentoService : IDepartamentoService
    {
        private readonly IDepartamentoRepository _repository;

        public DepartamentoService(IDepartamentoRepository repository)
        {
            _repository = repository;
        }

        private void ValidarDepartamento(Departamento dep)
        {
            if (string.IsNullOrWhiteSpace(dep.Direccion))
                throw new ArgumentException("La dirección no puede estar vacía.");
            if (string.IsNullOrWhiteSpace(dep.Colonia))
                throw new ArgumentException("La colonia no puede estar vacía.");
            if (string.IsNullOrWhiteSpace(dep.Ciudad))
                throw new ArgumentException("La ciudad no puede estar vacía.");

            if (dep.Habitaciones <= 0)
                throw new ArgumentException("La cantidad de habitaciones debe ser mayor a cero.");

            if (dep.PrecioRenta <= 0)
                throw new ArgumentException("El precio de renta debe ser mayor a cero.");

            if (dep.Estado != "Disponible" && dep.Estado != "Rentado" && dep.Estado != "Mantenimiento")
                throw new ArgumentException("El estado debe ser estrictamente: 'Disponible', 'Rentado' o 'Mantenimiento'.");

            if (dep.Estado == "Rentado")
            {
                if (string.IsNullOrWhiteSpace(dep.Arrendatario))
                    throw new ArgumentException("Para un departamento Rentado, el Arrendatario es obligatorio.");
                if (!dep.FechaInicioRenta.HasValue)
                    throw new ArgumentException("Para un departamento Rentado, la Fecha de Inicio de Renta es obligatoria.");
            }
            else
            {
                dep.Arrendatario = null;
                dep.FechaInicioRenta = null;
            }
        }

        public void AgregarDepartamento(Departamento departamento)
        {
            ValidarDepartamento(departamento);
            _repository.AgregarDepartamento(departamento);
        }

        public IEnumerable<Departamento> ObtenerDepartamentos()
        {
            return _repository.ObtenerDepartamentos();
        }

        public IEnumerable<Departamento> ObtenerDepartamentosDisponibles()
        {
            return _repository.ObtenerDepartamentosDisponibles();
        }

        public IEnumerable<Departamento> BuscarPorFiltros(string? ciudad, string? colonia, string? estado, decimal? precioMin, decimal? precioMax)
        {
            return _repository.BuscarPorFiltros(ciudad, colonia, estado, precioMin, precioMax);
        }

        public void ActualizarDepartamento(Departamento departamento)
        {
            ValidarDepartamento(departamento);
            _repository.ActualizarDepartamento(departamento);
        }

        public void EliminarDepartamento(int id)
        {
            _repository.EliminarDepartamento(id);
        }

        public void CambiarEstado(int id, string nuevoEstado)
        {
            if (nuevoEstado != "Disponible" && nuevoEstado != "Rentado" && nuevoEstado != "Mantenimiento")
                throw new ArgumentException("El estado debe ser estrictamente: 'Disponible', 'Rentado' o 'Mantenimiento'.");

            var dep = _repository.ObtenerPorId(id);
            if (dep == null)
                throw new KeyNotFoundException("Departamento no encontrado.");

            dep.Estado = nuevoEstado;
            if (nuevoEstado == "Rentado" && (string.IsNullOrWhiteSpace(dep.Arrendatario) || !dep.FechaInicioRenta.HasValue))
            {
                throw new InvalidOperationException("No se puede cambiar el estado a Rentado sin especificar Arrendatario y Fecha de Inicio.");
            }
            if (nuevoEstado != "Rentado")
            {
                dep.Arrendatario = null;
                dep.FechaInicioRenta = null;
            }

            _repository.ActualizarDepartamento(dep);
        }

        public Departamento? ObtenerPorId(int id)
        {
            return _repository.ObtenerPorId(id);
        }
    }
}
