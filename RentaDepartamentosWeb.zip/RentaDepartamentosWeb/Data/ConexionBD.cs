using Microsoft.Data.SqlClient;
using Microsoft.Extensions.Configuration;

namespace RentaDepartamentosWeb.Data
{
    public class ConexionBD
    {
        private readonly string _connectionString;

        public ConexionBD(IConfiguration configuration)
        {
            _connectionString = configuration.GetConnectionString("ConexionSQL")
                ?? throw new System.ArgumentNullException("Cadena de conexión 'ConexionSQL' no encontrada.");
        }

        public SqlConnection ObtenerConexion()
        {
            return new SqlConnection(_connectionString);
        }
    }
}
