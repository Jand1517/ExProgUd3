Actúa como un Arquitecto de Software Senior experto en .NET y Clean Code. Vamos a desarrollar las capas del "Sistema Web de Renta de Departamentos" utilizando ASP.NET Core MVC (C#) y SQL Server basado estrictamente en las especificaciones técnicas suministradas.

El proyecto se encuentra en una carpeta raíz estructurada. No utilizaremos Entity Framework; todas las operaciones a la base de datos se deben realizar con ADO.NET (Microsoft.Data.SqlClient) mediante consultas SQL parametrizadas directas. 

Por favor, genera el código completo, limpio, indentado y estructurado, removiendo comentarios explicativos redundantes o innecesarios dentro del código C#. 
---

### 1. CONFIGURACIÓN DE CONEXIÓN
Genera el bloque exacto para 'appsettings.json':
{
  "ConnectionStrings": {
    "ConexionSQL": "Server=localhost;Database=RentaDepartamentos;Trusted_Connection=True;TrustServerCertificate=True;"
  }
}

### 2. CAPA DE DATOS Y MODELO (Data / Models)
- 'Models/Departamento.cs': Clase con las propiedades exactas de la tabla: Id (int), Direccion (string), Colonia (string), Ciudad (string), Habitaciones (int), Banios (int), PrecioRenta (decimal), Estado (string), Arrendatario (string), FechaInicioRenta (DateTime?).
- 'Data/ConexionBD.cs': Clase que reciba IConfiguration por inyección de dependencias y exponga el método SqlConnection ObtenerConexion().

### 3. REPOSITORIO (Repositories) - Aplicando SOLID (S, I, D)
- 'Repositories/IDepartamentoRepository.cs': Interfaz que declare los métodos:
  * void AgregarDepartamento(Departamento departamento);
  * IEnumerable<Departamento> ObtenerDepartamentos();
  * IEnumerable<Departamento> ObtenerDepartamentosDisponibles();
  * IEnumerable<Departamento> BuscarPorFiltros(string ciudad, string colonia, string estado, decimal? precioMin, decimal? precioMax);
  * void ActualizarDepartamento(Departamento departamento);
  * void EliminarDepartamento(int id);
  * void CambiarEstado(int id, string nuevoEstado);
- 'Repositories/DepartamentoRepository.cs': Implementación completa con ADO.NET. Usa bloques 'using' y mapea los parámetros de SqlCommand adecuadamente. Controla los nulos de 'Arrendatario' y 'FechaInicioRenta' usando DBNull.Value cuando sea necesario.

### 4. CAPA DE SERVICIO / REGLAS DE NEGOCIO (Services)
- 'Services/IDepartamentoService.cs' e 'Services/DepartamentoService.cs': Capa intermedia que inyecta IDepartamentoRepository y aplica las siguientes validaciones antes de mandar a la base de datos (lanza excepciones si fallan):
  * Dirección, Colonia y Ciudad no vacías.
  * PrecioRenta y Habitaciones mayores a cero.
  * El Estado debe ser estrictamente: "Disponible", "Rentado" o "Mantenimiento".
  * Si el estado es "Rentado", exige que Arrendatario y FechaInicioRenta no sean nulos. Si es otro estado, limpia o setea esos campos en nulo automáticamente.

### 5. CONTROLADOR (Controllers/DepartamentoController.cs)
- Implementa 'DepartamentoController' inyectando 'IDepartamentoService'. Debe contener las acciones GET y POST correspondientes para: Index(), Disponibles(), Buscar(), Create(), Edit(int id), Details(int id) y Delete(int id). Agrega manejo de errores capturando las excepciones del servicio para mostrarlas en el ModelState.

### 6. REGISTRO DE DEPENDENCIAS (Program.cs)
- Muestra los comandos específicos de builder.Services.AddScoped o AddTransient necesarios para registrar ConexionBD, IDepartamentoRepository y IDepartamentoService.

### 7. VISTAS RAZOR (.cshtml)
Genera vistas limpias utilizando HTML5 y Bootstrap 5 básico:
- 'Views/Departamentos/Index.cshtml': Tabla con todas las columnas y enlaces de acción.
- 'Views/Departamentos/Disponibles.cshtml': Tabla exclusiva para los departamentos disponibles.
- 'Views/Departamentos/Buscar.cshtml': Panel con formulario de filtros (Ciudad, Colonia, Estado [select], rango de precios) y una tabla de resultados abajo.
- 'Views/Departamentos/Create.cshtml' y 'Edit.cshtml': Formularios funcionales. Incluye un script JS simple al final para que los campos "Arrendatario" y "FechaInicioRenta" se habiliten/deshabiliten dinámicamente según el valor seleccionado en el select de "Estado".

---
REQUISITO CRÍTICO DE FORMATO:
- Evita explicaciones extensas de texto fuera del código.
- No incluyas comentarios internos en el código C# a menos que sean estrictamente necesarios para una lógica compleja. Usa nombres de métodos autoexplicativos y limpios.