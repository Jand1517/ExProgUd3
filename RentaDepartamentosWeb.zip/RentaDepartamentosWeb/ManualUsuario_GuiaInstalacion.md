# Manual de Usuario y Guía de Instalación
## Sistema Web de Renta de Departamentos

Este documento contiene las especificaciones estructuradas para la instalación, configuración y el uso del **Sistema Web de Renta de Departamentos**, desarrollado sobre la plataforma ASP.NET Core MVC con persistencia en SQL Server mediante consultas directas con ADO.NET (Microsoft.Data.SqlClient).

---

## 1. GUÍA DE INSTALACIÓN

### 1.1. Prerrequisitos del Sistema
Para la compilación, despliegue y ejecución de este sistema, se requiere contar con el siguiente entorno de software instalado:
- **SDK de .NET 10.0** (o superior).
- **Microsoft SQL Server** (Edición LocalDB, Express, Standard o Enterprise).
- Un cliente de base de datos SQL (por ejemplo, SQL Server Management Studio o la extensión SQL Server en VS Code).
- **Navegador Web** compatible con HTML5, CSS3 y Bootstrap 5 (Microsoft Edge, Google Chrome, Mozilla Firefox, Safari).

### 1.2. Configuración de la Base de Datos
El sistema opera sobre una base de datos denominada `RentaDepartamentos` y utiliza una sola tabla llamada `Departamentos`.

Ejecute el siguiente script SQL en su instancia de SQL Server para crear la base de datos, la tabla y establecer las restricciones de integridad y dominio requeridas:

```sql
-- 1. Creación de la base de datos
CREATE DATABASE RentaDepartamentos;
GO

USE RentaDepartamentos;
GO

-- 2. Creación de la tabla Departamentos
CREATE TABLE Departamentos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Direccion NVARCHAR(250) NOT NULL,
    Colonia NVARCHAR(150) NOT NULL,
    Ciudad NVARCHAR(150) NOT NULL,
    Habitaciones INT NOT NULL,
    Banios INT NOT NULL,
    PrecioRenta DECIMAL(18,2) NOT NULL,
    Estado VARCHAR(20) NOT NULL,
    Arrendatario NVARCHAR(150) NULL,
    FechaInicioRenta DATETIME NULL,
    
    -- Restricciones de validación
    CONSTRAINT CK_Departamentos_Habitaciones CHECK (Habitaciones > 0),
    CONSTRAINT CK_Departamentos_Banios CHECK (Banios >= 0),
    CONSTRAINT CK_Departamentos_PrecioRenta CHECK (PrecioRenta > 0),
    CONSTRAINT CK_Departamentos_Estado CHECK (Estado IN ('Disponible', 'Rentado', 'Mantenimiento'))
);
GO
```

### 1.3. Configuración del Archivo de Conexión del Proyecto
Para que la aplicación se conecte a la base de datos creada, se debe configurar la cadena de conexión en el archivo `appsettings.json` ubicado en la raíz del proyecto.

Abra [appsettings.json](file:///C:/Users/josse/Downloads/RentaDepartamentosWeb/appsettings.json) y asegúrese de que contenga la sección `ConnectionStrings` con la propiedad `ConexionSQL` apuntando a su servidor local:

```json
{
  "ConnectionStrings": {
    "ConexionSQL": "Server=localhost;Database=RentaDepartamentos;Trusted_Connection=True;TrustServerCertificate=True;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```

*Nota: Modifique el parámetro `Server=localhost` si su instancia local de SQL Server utiliza un nombre específico (ej. `Server=(localdb)\MSSQLLocalDB` o `Server=.\SQLEXPRESS`).*

### 1.4. Compilación y Ejecución desde la Consola
Una vez configurados los prerrequisitos y la cadena de conexión, realice los siguientes pasos desde la terminal de comandos (PowerShell o CMD) en la raíz del proyecto:

1. **Restaurar las dependencias del proyecto:**
   ```bash
   dotnet restore
   ```
   *Este comando descarga el paquete NuGet `Microsoft.Data.SqlClient` especificado en el archivo de proyecto.*

2. **Compilar el proyecto:**
   ```bash
   dotnet build
   ```
   *Verifique que la compilación finalice con cero errores.*

3. **Ejecutar la aplicación:**
   ```bash
   dotnet run
   ```
   *El servidor local iniciará y expondrá los puertos de acceso.*

### 1.5. Puertos y Direcciones de Acceso
Por defecto, la aplicación estará disponible en las siguientes direcciones locales según la configuración definida en `launchSettings.json`:
- **Protocolo seguro (HTTPS):** [https://localhost:7018](https://localhost:7018)
- **Protocolo estándar (HTTP):** [http://localhost:5019](http://localhost:5019)

Abra cualquiera de estas direcciones en su navegador para interactuar con la interfaz del sistema.

---

## 2. MANUAL DE USUARIO

El **Sistema Web de Renta de Departamentos** permite la gestión integral del inventario de inmuebles y el control de su estado de arrendamiento.

### 2.1. Descripción de Módulos y Navegación
La aplicación web utiliza un diseño basado en Bootstrap 5 que se compone de una barra de navegación superior (Navbar) que da acceso directo a los siguientes apartados:
1. **Ver Todos:** Módulo general de inventario de departamentos.
2. **Disponibles:** Vista rápida de departamentos listos para renta.
3. **Buscar:** Buscador avanzado con filtros parametrizables.
4. **Nuevo Departamento:** Formulario de registro de registros.

---

### 2.2. Operación de las Funcionalidades

#### A. Consulta de Inventario Completo (`/Departamentos/Index`)
- **Acceso:** Desde el enlace "Ver Todos" en la barra de navegación.
- **Descripción:** Muestra una tabla con todos los departamentos registrados en la base de datos (independientemente de su estado). 
- **Estructura de la tabla:** Presenta las columnas: Dirección, Colonia, Ciudad, Habitaciones, Baños, Precio de Renta, Estado, Arrendatario y Fecha de Inicio de Renta.
- **Acciones Disponibles:** Cada fila de la tabla contiene tres enlaces en la última columna:
  - **Editar:** Abre la interfaz de edición del registro.
  - **Detalles:** Muestra la ficha técnica completa del departamento.
  - **Eliminar:** Dirige a la pantalla de confirmación para dar de baja el registro.

#### B. Visualización de Departamentos Disponibles (`/Departamentos/Disponibles`)
- **Acceso:** Desde el enlace "Disponibles" en la barra de navegación o navegando directamente a `/Departamentos/Disponibles`.
- **Descripción:** Filtra de forma automática la lista de departamentos mostrando únicamente aquellos cuyo campo `Estado` es exactamente igual a `"Disponible"`. Excluye los departamentos bajo los estados de `"Rentado"` o `"Mantenimiento"`.

#### C. Búsqueda y Filtrado Avanzado (`/Departamentos/Buscar`)
- **Acceso:** Desde el enlace "Buscar" en la barra de navegación.
- **Descripción:** Proporciona un panel superior con un formulario de filtros y una sección de resultados en la parte inferior.
- **Filtros Disponibles:**
  - **Ciudad:** Caja de texto para buscar por coincidencia exacta o parcial.
  - **Colonia:** Caja de texto para delimitar por zona geográfica.
  - **Estado:** Selector desplegable (Dropdown) con las opciones: *Seleccione Estado, Disponible, Rentado, Mantenimiento*.
  - **Precio Mínimo / Precio Máximo:** Campos numéricos para definir un rango de renta mensual.
- **Procedimiento:** Ingrese los valores deseados en los filtros y presione el botón **"Buscar"**. La tabla inferior se actualizará con los registros que cumplan simultáneamente con todos los criterios ingresados.

#### D. Registro de Nuevo Departamento (`/Departamentos/Create`)
- **Acceso:** Desde el enlace "Nuevo Departamento" en la barra de navegación.
- **Campos a Completar:**
  - **Dirección:** (Texto) Calle y número exterior/interior.
  - **Colonia:** (Texto) Zona residencial o colonia.
  - **Ciudad:** (Texto) Municipio o ciudad.
  - **Habitaciones:** (Número entero) Cantidad total de recámaras.
  - **Baños:** (Número entero) Cantidad total de baños completos o medios baños.
  - **Precio de Renta:** (Número decimal) Monto mensual de arrendamiento.
  - **Estado:** Selector desplegable con las opciones fijas: `Disponible`, `Rentado` y `Mantenimiento`.
  - **Arrendatario:** (Texto) Nombre completo del inquilino (Opcional/Obligatorio según el Estado).
  - **Fecha de Inicio de Renta:** (Fecha) Día de inicio del contrato (Opcional/Obligatorio según el Estado).

- **Comportamiento Dinámico del Formulario (Script JS):**
  - Si el usuario selecciona el estado **"Rentado"**, los campos **"Arrendatario"** y **"Fecha de Inicio de Renta"** se habilitan de inmediato en la interfaz para permitir la captura.
  - Si el usuario selecciona **"Disponible"** o **"Mantenimiento"**, el script deshabilita automáticamente ambos campos y borra cualquier texto previamente escrito en ellos, previniendo el envío de datos inconsistentes.

#### E. Modificación de Departamento (`/Departamentos/Edit/{id}`)
- **Acceso:** Presionando el botón "Editar" en cualquier listado.
- **Descripción:** Carga los valores actuales del departamento seleccionado dentro de un formulario idéntico al de creación.
- **Funcionamiento:** Mantiene el mismo script de comportamiento dinámico para habilitar/deshabilitar los campos "Arrendatario" y "Fecha de Inicio de Renta" en función del estado que se asigne durante la edición.

#### F. Visualización de Ficha de Detalles (`/Departamentos/Details/{id}`)
- **Acceso:** Presionando "Detalles" en los listados.
- **Descripción:** Despliega una vista de solo lectura que organiza la información completa del departamento en una tarjeta estructurada. Útil para consultar la información sin riesgo de realizar modificaciones accidentales.

#### G. Eliminación de Registros (`/Departamentos/Delete/{id}`)
- **Acceso:** Presionando "Eliminar" en los listados.
- **Descripción:** Carga una pantalla de confirmación que expone los datos principales del departamento. 
- **Procedimiento:** El usuario debe presionar el botón **"Eliminar"** en color rojo para confirmar la acción, la cual ejecutará una sentencia SQL directa en la base de datos para remover definitivamente el registro. Para cancelar, se dispone de un enlace de retorno a la lista general.

---

### 2.3. Reglas de Validación y de Negocio

El sistema cuenta con una capa de servicios (`DepartamentoService`) que valida las siguientes reglas estrictas antes de procesar inserciones o actualizaciones en la base de datos. Si alguna de estas condiciones no se cumple, el sistema cancela la operación y despliega el mensaje de error correspondiente en la interfaz:

| Campo | Regla / Restricción Aplicada | Comportamiento en el Servidor |
| :--- | :--- | :--- |
| **Dirección** | No debe estar vacío ni contener solo espacios en blanco. | Lanza excepción de validación. |
| **Colonia** | No debe estar vacío ni contener solo espacios en blanco. | Lanza excepción de validación. |
| **Ciudad** | No debe estar vacío ni contener solo espacios en blanco. | Lanza excepción de validación. |
| **Habitaciones** | Debe ser un número estrictamente mayor que cero (1 o más). | Lanza excepción de validación. |
| **Precio de Renta** | Debe ser un valor decimal mayor a cero. | Lanza excepción de validación. |
| **Estado** | Debe pertenecer exactamente a uno de estos valores: `"Disponible"`, `"Rentado"` o `"Mantenimiento"`. | Lanza excepción de validación. |
| **Arrendatario / Fecha** *(Si el Estado es "Rentado")* | Ambos campos son obligatorios. No pueden ser nulos ni vacíos. | Lanza excepción de validación. |
| **Arrendatario / Fecha** *(Si el Estado es diferente)* | Se asigna automáticamente valor nulo (`null`) al guardarse. | Limpieza automática de datos. |
