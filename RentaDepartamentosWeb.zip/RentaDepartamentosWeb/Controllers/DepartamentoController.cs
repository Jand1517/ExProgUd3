using System;
using Microsoft.AspNetCore.Mvc;
using RentaDepartamentosWeb.Models;
using RentaDepartamentosWeb.Services;

namespace RentaDepartamentosWeb.Controllers
{
    public class DepartamentoController : Controller
    {
        private readonly IDepartamentoService _service;

        public DepartamentoController(IDepartamentoService service)
        {
            _service = service;
        }

        public IActionResult Index()
        {
            var departamentos = _service.ObtenerDepartamentos();
            return View(departamentos);
        }

        public IActionResult Disponibles()
        {
            var departamentos = _service.ObtenerDepartamentosDisponibles();
            return View(departamentos);
        }

        public IActionResult Buscar(string? ciudad, string? colonia, string? estado, decimal? precioMin, decimal? precioMax)
        {
            var departamentos = _service.BuscarPorFiltros(ciudad, colonia, estado, precioMin, precioMax);

            ViewBag.Ciudad = ciudad;
            ViewBag.Colonia = colonia;
            ViewBag.Estado = estado;
            ViewBag.PrecioMin = precioMin;
            ViewBag.PrecioMax = precioMax;

            return View(departamentos);
        }

        public IActionResult Create()
        {
            return View(new Departamento());
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Create(Departamento departamento)
        {
            try
            {
                _service.AgregarDepartamento(departamento);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
                return View(departamento);
            }
        }

        public IActionResult Edit(int id)
        {
            var departamento = _service.ObtenerPorId(id);
            if (departamento == null)
            {
                return NotFound();
            }
            return View(departamento);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Edit(int id, Departamento departamento)
        {
            if (id != departamento.Id)
            {
                return BadRequest();
            }

            try
            {
                _service.ActualizarDepartamento(departamento);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                ModelState.AddModelError(string.Empty, ex.Message);
                return View(departamento);
            }
        }

        public IActionResult Details(int id)
        {
            var departamento = _service.ObtenerPorId(id);
            if (departamento == null)
            {
                return NotFound();
            }
            return View(departamento);
        }

        public IActionResult Delete(int id)
        {
            var departamento = _service.ObtenerPorId(id);
            if (departamento == null)
            {
                return NotFound();
            }
            return View(departamento);
        }

        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public IActionResult DeleteConfirmed(int id)
        {
            try
            {
                _service.EliminarDepartamento(id);
                return RedirectToAction(nameof(Index));
            }
            catch (Exception ex)
            {
                var departamento = _service.ObtenerPorId(id);
                ModelState.AddModelError(string.Empty, $"Error al eliminar: {ex.Message}");
                return View(departamento);
            }
        }
    }
}
