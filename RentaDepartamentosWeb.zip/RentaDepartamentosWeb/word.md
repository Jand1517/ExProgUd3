"Basado en el código anterior, genérame el texto estructurado para el Manual de Usuario y la Guía de Instalación para un documento de Word (.docx). Esto es solo para copiar y pegar. Generalo debajo de esta instrucción"

---

# DOCUMENTO TÉCNICO Y OPERATIVO: DEPATOURS UTM
## Manual de Usuario y Guía de Instalación de la Aplicación Web

---

### PARTE 1: GUÍA DE INSTALACIÓN Y CONFIGURACIÓN DEL SISTEMA

#### 1. REQUISITOS PREVIOS DEL SISTEMA
Para poder compilar y ejecutar el sistema de DepaTours UTM, asegúrese de tener instalado el siguiente software en el equipo servidor o de desarrollo:
1. **.NET 10.0 SDK** (Software Development Kit) o superior.
2. **Microsoft SQL Server** (Edición Express, LocalDB o superior).
3. **Microsoft SQL Server Management Studio (SSMS)** o extensión equivalente para ejecutar scripts SQL.
4. **Navegador Web** moderno (Google Chrome, Microsoft Edge, Mozilla Firefox o Safari).

#### 2. CONFIGURACIÓN Y PREPARACIÓN DE LA BASE DE DATOS
El sistema almacena la información de los departamentos en una base de datos relacional. Siga estos pasos para configurarla:

1. Abra su cliente de SQL Server (como SSMS) y conéctese a su instancia de base de datos local.
2. Abra una ventana de nueva consulta ("New Query").
3. Copie, pegue y ejecute el siguiente script DDL para crear la base de datos `RentaDepartamentos` y la tabla `Departamentos` con sus respectivas restricciones de validación:

```sql
-- Creación de la base de datos
CREATE DATABASE RentaDepartamentos;
GO

USE RentaDepartamentos;
GO

-- Creación de la tabla Departamentos
CREATE TABLE Departamentos (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Direccion NVARCHAR(250) NOT NULL,
    Colonia NVARCHAR(150) NOT NULL,
    Ciudad NVARCHAR(150) NOT NULL,
    Habitaciones INT NOT NULL,
    Banios INT NOT NULL,
    PrecioRenta DECIMAL(18,2) NOT NULL,
    Estado VARCHAR(20) NOT NULL,
    Arrendatario NVARCHAR(150) NULL,
    FechaInicioRenta DATETIME NULL,
    
    -- Restricciones de validación a nivel base de datos
    CONSTRAINT CK_Departamentos_Habitaciones CHECK (Habitaciones > 0),
    CONSTRAINT CK_Departamentos_Banios CHECK (Banios >= 0),
    CONSTRAINT CK_Departamentos_PrecioRenta CHECK (PrecioRenta > 0),
    CONSTRAINT CK_Departamentos_Estado CHECK (Estado IN ('Disponible', 'Rentado', 'Mantenimiento'))
);
GO
```

#### 3. CONFIGURACIÓN DEL ARCHIVO APPSETTINGS.JSON
Para enlazar la aplicación web con la base de datos recién creada:
1. Navegue al directorio raíz del proyecto y abra el archivo `appsettings.json`.
2. Verifique o configure la cadena de conexión en la propiedad `ConexionSQL` de acuerdo al nombre de su servidor SQL Server local.
3. El archivo debe quedar estructurado de la siguiente manera:

```json
{
  "ConnectionStrings": {
    "ConexionSQL": "Server=localhost;Database=RentaDepartamentos;Trusted_Connection=True;TrustServerCertificate=True;"
  },
  "Logging": {
    "LogLevel": {
      "Default": "Information",
      "Microsoft.AspNetCore": "Warning"
    }
  },
  "AllowedHosts": "*"
}
```
*Nota: Si su base de datos local no utiliza Windows Authentication o se encuentra en una instancia nombrada, reemplace `Server=localhost` por la dirección e instancia correcta (ej. `Server=(localdb)\MSSQLLocalDB` o `Server=.\SQLEXPRESS`) e introduzca las credenciales correspondientes si aplica.*

#### 4. COMPILACIÓN Y DESPLIEGUE DESDE LA CONSOLA
1. Abra la terminal de comandos (PowerShell o CMD) y colóquese en la carpeta raíz del proyecto `RentaDepartamentosWeb`.
2. Ejecute el siguiente comando para restaurar los paquetes de dependencias de NuGet (incluyendo el driver `Microsoft.Data.SqlClient` versión 7.0.2):
   `dotnet restore`
3. Realice la compilación del proyecto ejecutando:
   `dotnet build`
4. Inicie el servidor web de desarrollo local con el comando:
   `dotnet run`

#### 5. DIRECCIONES DE ACCESO LOCAL
Una vez iniciado el servidor web, la consola mostrará que el sitio está escuchando peticiones. Puede acceder a él a través de su navegador de preferencia en las siguientes direcciones predeterminadas:
- **Dirección HTTP ordinaria:** `http://localhost:5019/`
- **Dirección HTTPS segura:** `https://localhost:7018/`

---

### PARTE 2: MANUAL DE USUARIO DE LA APLICACIÓN WEB

#### 1. INTRODUCCIÓN AL SISTEMA
La plataforma web de **DepaTours UTM** es un sistema de administración interna diseñado para el control de inventario de departamentos, permitiendo el registro, visualización, búsqueda avanzada y administración de estados de alquiler (Disponible, Rentado y Mantenimiento) bajo reglas de negocio estrictas.

#### 2. ESTRUCTURA Y NAVEGACIÓN DE LA INTERFAZ
El sistema cuenta con una barra de navegación superior (Navbar) que incluye la marca del negocio **DepaTours UTM** y accesos directos a los módulos operativos, además de un control de tema dinámico:
- **Ver Todos:** Inventario completo de inmuebles.
- **Disponibles:** Acceso rápido a departamentos listos para renta.
- **Buscar:** Filtros de búsqueda especializados.
- **Nuevo Departamento:** Registro de nuevos inmuebles.
- **Botón de Modo Claro / Oscuro (Tema):** Ubicado a la derecha de la barra de navegación. Este botón cambia la paleta de colores del sitio de forma manual. Por defecto, el sistema activa el modo oscuro automáticamente entre las **6:00 PM y las 6:00 AM** según la hora local del dispositivo del usuario.

#### 3. GUÍA OPERATIVA DE LOS MÓDULOS

##### A. MÓDULO DE INVENTARIO COMPLETO (RUTA: `/Departamento/Index`)
Este módulo presenta en formato tabular todos los departamentos registrados en la base de datos de DepaTours UTM.
- **Campos mostrados:** Dirección, Colonia, Ciudad, Habitaciones, Baños, Monto Renta, Estado (con etiquetas visuales de color), Arrendatario y Fecha de Inicio de Renta.
- **Acciones Rápidas:** En la columna derecha de cada registro se disponen tres botones:
  - **Editar:** Permite actualizar cualquier dato del departamento.
  - **Detalles:** Abre una tarjeta técnica con la información completa de solo lectura.
  - **Eliminar:** Dirige a una ventana de confirmación para borrar de forma definitiva el registro de la base de datos.
- **Botón "Nuevo Departamento":** Ubicado en la parte superior derecha (de color rojo `#c51919`), permite redirigirse de manera rápida al formulario de registro.

##### B. MÓDULO DE DEPARTAMENTOS DISPONIBLES (RUTA: `/Departamento/Disponibles`)
Filtra automáticamente la lista del inventario y despliega única y exclusivamente los inmuebles que tienen el estado de **"Disponible"**. Ideal para que los agentes ubiquen de inmediato las opciones listas para ofrecer a clientes.

##### C. MÓDULO DE BÚSQUEDA Y FILTRADO (RUTA: `/Departamento/Buscar`)
Proporciona un formulario de filtros en la parte superior que se pueden combinar de forma libre:
- **Criterios de búsqueda:** Ciudad (búsqueda parcial), Colonia (búsqueda parcial), Estado (desplegable con opciones de Disponible, Rentado y Mantenimiento) y Rango de Precios (Monto Mínimo y Monto Máximo).
- **Instrucciones:** Escriba o seleccione los filtros deseados y presione el botón **"Buscar"**. Los resultados que cumplan con todos los criterios se listarán en la tabla de la parte inferior. Presione el botón **"Limpiar"** para borrar los filtros y reestablecer la vista.

##### D. MÓDULO DE REGISTRO DE NUEVO DEPARTAMENTO (RUTA: `/Departamento/Create`)
Presenta un formulario limpio para ingresar los datos del inmueble. El comportamiento del formulario es dinámico gracias a un script JavaScript integrado:
- **Comportamiento Dinámico del Estado:**
  - Si en el campo desplegable **"Estado"** selecciona **"Rentado"**, los campos **"Arrendatario"** (Nombre completo del inquilino) y **"Fecha de Inicio de Renta"** se habilitan de inmediato y se vuelven obligatorios.
  - Si selecciona cualquier otro estado (**"Disponible"** o **"Mantenimiento"**), los campos de **"Arrendatario"** y **"Fecha de Inicio de Renta"** se deshabilitan automáticamente, borrándose cualquier texto o fecha que contuvieran para prevenir inconsistencias en la base de datos.

##### E. MÓDULO DE EDICIÓN DE DEPARTAMENTO (RUTA: `/Departamento/Edit/{id}`)
Este formulario permite modificar un departamento existente. Mantiene exactamente las mismas validaciones en tiempo real y comportamiento dinámico del estado que el formulario de creación.

##### F. ELIMINACIÓN DE REGISTROS (RUTA: `/Departamento/Delete/{id}`)
Al hacer clic en "Eliminar" desde cualquier listado, el sistema muestra los datos resumidos del departamento y le pide confirmar la operación. Al confirmar, se realiza un borrado físico en la base de datos.

---

### PARTE 3: REGLAS DE NEGOCIO Y VALIDACIÓN

Para garantizar la integridad y calidad de la información, el sistema cuenta con reglas en la capa de servicios (`DepartamentoService`) que impiden el registro de datos incorrectos en SQL Server. De no cumplirse alguna regla, la operación se cancela y se muestra el mensaje de error correspondiente al usuario:

| Campo / Parámetro | Tipo de Validación | Regla de Negocio / Restricción |
| :--- | :--- | :--- |
| **Dirección** | Obligatorio | No puede estar vacío ni contener únicamente espacios en blanco. |
| **Colonia** | Obligatorio | No puede estar vacío ni contener únicamente espacios en blanco. |
| **Ciudad** | Obligatorio | No puede estar vacío ni contener únicamente espacios en blanco. |
| **Habitaciones** | Numérico entero | Debe ser estrictamente mayor a cero (mínimo 1). |
| **Baños** | Numérico entero | Debe ser mayor o igual a cero. |
| **Precio de Renta** | Numérico decimal | Debe ser estrictamente mayor a cero (monto positivo). |
| **Estado** | Selección obligatoria | Debe ser exclusivamente uno de estos tres valores: "Disponible", "Rentado" o "Mantenimiento". |
| **Arrendatario** | Condicional | Obligatorio si el Estado es "Rentado". Se limpia y se guarda como `NULL` si el Estado es diferente. |
| **Fecha de Inicio** | Condicional | Obligatorio si el Estado es "Rentado". Se limpia y se guarda como `NULL` si el Estado es diferente. |

---
**DepaTours UTM** - Todos los derechos reservados &copy; 2026.
*Licencia de Operación Turística: Reg. Sectur No. DTU-99208-MX.*