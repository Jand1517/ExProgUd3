using System.Collections.Generic;
using RentaDepartamentosWeb.Models;

namespace RentaDepartamentosWeb.Repositories
{
    public interface IDepartamentoRepository
    {
        void AgregarDepartamento(Departamento departamento);
        IEnumerable<Departamento> ObtenerDepartamentos();
        IEnumerable<Departamento> ObtenerDepartamentosDisponibles();
        IEnumerable<Departamento> BuscarPorFiltros(string? ciudad, string? colonia, string? estado, decimal? precioMin, decimal? precioMax);
        void ActualizarDepartamento(Departamento departamento);
        void EliminarDepartamento(int id);
        void CambiarEstado(int id, string nuevoEstado);
        Departamento? ObtenerPorId(int id);
    }
}
