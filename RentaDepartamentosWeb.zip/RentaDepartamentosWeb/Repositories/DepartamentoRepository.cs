using System;
using System.Collections.Generic;
using Microsoft.Data.SqlClient;
using RentaDepartamentosWeb.Data;
using RentaDepartamentosWeb.Models;

namespace RentaDepartamentosWeb.Repositories
{
    public class DepartamentoRepository : IDepartamentoRepository
    {
        private readonly ConexionBD _conexion;

        public DepartamentoRepository(ConexionBD conexion)
        {
            _conexion = conexion;
        }

        private Departamento MapearDepartamento(SqlDataReader reader)
        {
            return new Departamento
            {
                Id = (int)reader["Id"],
                Direccion = reader["Direccion"].ToString() ?? string.Empty,
                Colonia = reader["Colonia"].ToString() ?? string.Empty,
                Ciudad = reader["Ciudad"].ToString() ?? string.Empty,
                Habitaciones = (int)reader["Habitaciones"],
                Banios = (int)reader["Banios"],
                PrecioRenta = (decimal)reader["PrecioRenta"],
                Estado = reader["Estado"].ToString() ?? string.Empty,
                Arrendatario = reader["Arrendatario"] == DBNull.Value ? null : reader["Arrendatario"].ToString(),
                FechaInicioRenta = reader["FechaInicioRenta"] == DBNull.Value ? null : (DateTime?)reader["FechaInicioRenta"]
            };
        }

        public void AgregarDepartamento(Departamento departamento)
        {
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = @"INSERT INTO Departamentos (Direccion, Colonia, Ciudad, Habitaciones, Banios, PrecioRenta, Estado, Arrendatario, FechaInicioRenta) 
                              VALUES (@Direccion, @Colonia, @Ciudad, @Habitaciones, @Banios, @PrecioRenta, @Estado, @Arrendatario, @FechaInicioRenta)";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Direccion", departamento.Direccion);
                    cmd.Parameters.AddWithValue("@Colonia", departamento.Colonia);
                    cmd.Parameters.AddWithValue("@Ciudad", departamento.Ciudad);
                    cmd.Parameters.AddWithValue("@Habitaciones", departamento.Habitaciones);
                    cmd.Parameters.AddWithValue("@Banios", departamento.Banios);
                    cmd.Parameters.AddWithValue("@PrecioRenta", departamento.PrecioRenta);
                    cmd.Parameters.AddWithValue("@Estado", departamento.Estado);
                    cmd.Parameters.AddWithValue("@Arrendatario", (object?)departamento.Arrendatario ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FechaInicioRenta", (object?)departamento.FechaInicioRenta ?? DBNull.Value);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public IEnumerable<Departamento> ObtenerDepartamentos()
        {
            var list = new List<Departamento>();
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "SELECT Id, Direccion, Colonia, Ciudad, Habitaciones, Banios, PrecioRenta, Estado, Arrendatario, FechaInicioRenta FROM Departamentos";
                using (var cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(MapearDepartamento(reader));
                        }
                    }
                }
            }
            return list;
        }

        public IEnumerable<Departamento> ObtenerDepartamentosDisponibles()
        {
            var list = new List<Departamento>();
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "SELECT Id, Direccion, Colonia, Ciudad, Habitaciones, Banios, PrecioRenta, Estado, Arrendatario, FechaInicioRenta FROM Departamentos WHERE Estado = 'Disponible'";
                using (var cmd = new SqlCommand(query, conn))
                {
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(MapearDepartamento(reader));
                        }
                    }
                }
            }
            return list;
        }

        public IEnumerable<Departamento> BuscarPorFiltros(string? ciudad, string? colonia, string? estado, decimal? precioMin, decimal? precioMax)
        {
            var list = new List<Departamento>();
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "SELECT Id, Direccion, Colonia, Ciudad, Habitaciones, Banios, PrecioRenta, Estado, Arrendatario, FechaInicioRenta FROM Departamentos WHERE 1=1";

                if (!string.IsNullOrEmpty(ciudad))
                    query += " AND Ciudad LIKE '%' + @Ciudad + '%'";
                if (!string.IsNullOrEmpty(colonia))
                    query += " AND Colonia LIKE '%' + @Colonia + '%'";
                if (!string.IsNullOrEmpty(estado) && estado != "Seleccione Estado")
                    query += " AND Estado = @Estado";
                if (precioMin.HasValue)
                    query += " AND PrecioRenta >= @PrecioMin";
                if (precioMax.HasValue)
                    query += " AND PrecioRenta <= @PrecioMax";

                using (var cmd = new SqlCommand(query, conn))
                {
                    if (!string.IsNullOrEmpty(ciudad))
                        cmd.Parameters.AddWithValue("@Ciudad", ciudad);
                    if (!string.IsNullOrEmpty(colonia))
                        cmd.Parameters.AddWithValue("@Colonia", colonia);
                    if (!string.IsNullOrEmpty(estado) && estado != "Seleccione Estado")
                        cmd.Parameters.AddWithValue("@Estado", estado);
                    if (precioMin.HasValue)
                        cmd.Parameters.AddWithValue("@PrecioMin", precioMin.Value);
                    if (precioMax.HasValue)
                        cmd.Parameters.AddWithValue("@PrecioMax", precioMax.Value);

                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            list.Add(MapearDepartamento(reader));
                        }
                    }
                }
            }
            return list;
        }

        public void ActualizarDepartamento(Departamento departamento)
        {
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = @"UPDATE Departamentos 
                              SET Direccion = @Direccion, Colonia = @Colonia, Ciudad = @Ciudad, 
                                  Habitaciones = @Habitaciones, Banios = @Banios, PrecioRenta = @PrecioRenta, 
                                  Estado = @Estado, Arrendatario = @Arrendatario, FechaInicioRenta = @FechaInicioRenta 
                              WHERE Id = @Id";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", departamento.Id);
                    cmd.Parameters.AddWithValue("@Direccion", departamento.Direccion);
                    cmd.Parameters.AddWithValue("@Colonia", departamento.Colonia);
                    cmd.Parameters.AddWithValue("@Ciudad", departamento.Ciudad);
                    cmd.Parameters.AddWithValue("@Habitaciones", departamento.Habitaciones);
                    cmd.Parameters.AddWithValue("@Banios", departamento.Banios);
                    cmd.Parameters.AddWithValue("@PrecioRenta", departamento.PrecioRenta);
                    cmd.Parameters.AddWithValue("@Estado", departamento.Estado);
                    cmd.Parameters.AddWithValue("@Arrendatario", (object?)departamento.Arrendatario ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@FechaInicioRenta", (object?)departamento.FechaInicioRenta ?? DBNull.Value);

                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void EliminarDepartamento(int id)
        {
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "DELETE FROM Departamentos WHERE Id = @Id";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public void CambiarEstado(int id, string nuevoEstado)
        {
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "UPDATE Departamentos SET Estado = @Estado WHERE Id = @Id";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    cmd.Parameters.AddWithValue("@Estado", nuevoEstado);
                    conn.Open();
                    cmd.ExecuteNonQuery();
                }
            }
        }

        public Departamento? ObtenerPorId(int id)
        {
            using (var conn = _conexion.ObtenerConexion())
            {
                var query = "SELECT Id, Direccion, Colonia, Ciudad, Habitaciones, Banios, PrecioRenta, Estado, Arrendatario, FechaInicioRenta FROM Departamentos WHERE Id = @Id";
                using (var cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@Id", id);
                    conn.Open();
                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return MapearDepartamento(reader);
                        }
                    }
                }
            }
            return null;
        }
    }
}
